#!/bin/bash

pkg_name=indicator-china-weather

pwd
cp $pkg_name.spec ../../../src_house/$pkg_name-fork/
cp *.tar.* ../../../src_house/$pkg_name-fork/
