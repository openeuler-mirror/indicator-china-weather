/*
 * Copyright (C) 2020, KylinSoft Co., Ltd.
 *
 * Authors:
 *  Kobe Lee    lixiang@kylinos.cn/kobe24_lixiang@126.com
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; version 3.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "leftupsearchdelegate.h"
#include "data.h"
#include "mainwindow.h"

#include <QPainter>
#include <QPainterPath>
#include <QStyledItemDelegate>
#include <QStyle>
#include <QEvent>
#include <QDebug>

LeftUpSearchDelegate::LeftUpSearchDelegate(QObject *parent) :
    QStyledItemDelegate(parent)
{

}

LeftUpSearchDelegate::~LeftUpSearchDelegate()
{

}

void LeftUpSearchDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
    if(index.isValid())
    {
        painter->save();

        QVariant variant = index.data(Qt::UserRole);
        ItemData data = variant.value<ItemData>();

        //draw a item in ui
        QStyleOptionViewItem viewOption(option);

        //set position and size of rect
        QRectF rect;
//        rect.setX(option.rect.x());
//        rect.setY(option.rect.y());
        rect.setX(option.rect.x()+4);
        rect.setY(option.rect.y()+4);

//        rect.setWidth( option.rect.width()-1);
//        rect.setHeight(option.rect.height()-1);
        rect.setWidth( option.rect.width()-11);
        rect.setHeight(option.rect.height()-4);


        //use QPainterPath to paint a rect with boder-radius
        const qreal radius = 4;
        QPainterPath path;
        path.moveTo(rect.topRight() - QPointF(radius, 0));
        path.lineTo(rect.topLeft() + QPointF(radius, 0));
        path.quadTo(rect.topLeft(), rect.topLeft() + QPointF(0, radius));
        path.lineTo(rect.bottomLeft() + QPointF(0, -radius));
        path.quadTo(rect.bottomLeft(), rect.bottomLeft() + QPointF(radius, 0));
        path.lineTo(rect.bottomRight() - QPointF(radius, 0));
        path.quadTo(rect.bottomRight(), rect.bottomRight() + QPointF(0, -radius));
        path.lineTo(rect.topRight() + QPointF(0, radius));
        path.quadTo(rect.topRight(), rect.topRight() + QPointF(-radius, -0));

        //handle different event type
        if(option.state.testFlag(QStyle::State_Selected)) {
            //painter->setPen(QPen(Qt::blue));
            painter->setPen(Qt::NoPen);
            painter->setBrush(QColor(255, 255, 255));
            painter->setOpacity(0.1);
            painter->drawPath(path);
        } else if(option.state.testFlag(QStyle::State_MouseOver)) {
            //painter->setPen(QPen(Qt::green));
            painter->setPen(Qt::NoPen);
            painter->setBrush(QColor(255, 255, 255));
            painter->setOpacity(0.2);
            painter->drawPath(path);
        } else {
            //painter->setPen(QPen(Qt::gray));
            painter->setPen(Qt::NoPen);
            painter->setBrush(Qt::NoBrush);
            painter->drawPath(path);
        }

        //set the position of the text
//        QRect NameRect = QRect(rect.left()+8, rect.top(), rect.width()-30, 28);
        QRect NameRect = QRect(rect.left()+8, rect.top(), rect.width()-30, 28);
        QRect telRect = QRect(rect.left()+8, rect.bottom()-24, rect.width()-10, 22);

        QFont m_searchFontEmpty;
        m_searchFontEmpty.setPixelSize(14);
        QFont m_searchFontCity;
        m_searchFontCity.setPixelSize(15);
        QFont m_searchFontProvince;
        m_searchFontProvince.setPixelSize(12);
        // 更改搜索框有搜索结果和没有搜索结果的显示效果样式
        if(data.cityProvince == ""){
            QRect NameRect = QRect(rect.left()+22, rect.top() + 8, rect.width()-30, 28);
            painter->setPen(QPen(Qt::white));
//            painter->setFont(QFont("",14));
            painter->setFont(m_searchFontEmpty);
            painter->setOpacity(1);
            painter->drawText(NameRect, Qt::AlignLeft, data.cityName); //绘制城市名字
        }
        else{
        //painter->setPen(QPen(Qt::black));
        painter->setPen(QPen(Qt::white));
        painter->setFont(m_searchFontCity);
        painter->setOpacity(1);
        painter->drawText(NameRect, Qt::AlignLeft, data.cityName); //绘制城市名字

        //painter->setPen(QPen(Qt::black));
        painter->setPen(QPen(Qt::white));
//        painter->setFont(QFont("", 12));
        painter->setFont(m_searchFontProvince);
        painter->setOpacity(0.4);
        painter->drawText(telRect, Qt::AlignLeft, data.cityProvince); //绘制城市所属省份

        painter->restore();
        }
    }
}
extern int tempNumsOfCityInSearchResultList;
QSize LeftUpSearchDelegate::sizeHint(const QStyleOptionViewItem &option, const QModelIndex &index) const
{
//    return QSize(178, 50);
//  下拉列表item的宽度和高度
//    return QSize(141, 50);
    if(tempNumsOfCityInSearchResultList > 4)
    {
        return QSize(141, 50);
    }
    else
    {
        return QSize(151, 50);
    }


}
